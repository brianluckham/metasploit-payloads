#ifndef _METERPRETER_SOURCE_ELEVATOR_ELEVATOR_H
#define _METERPRETER_SOURCE_ELEVATOR_ELEVATOR_H

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#endif
