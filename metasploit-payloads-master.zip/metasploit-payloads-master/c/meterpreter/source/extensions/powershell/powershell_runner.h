/*!
  * @file powershell_runner.h
  * @brief This file was generated at 05/08/2020 07:16:29 UTC, do not modify directly.
  */

 #ifndef _METERPRETER_SOURCE_EXTENSION_POWERSHELL_RUNNER_H
 #define _METERPRETER_SOURCE_EXTENSION_POWERSHELL_RUNNER_H

 #define PSHRUNNER_DLL_LEN 64512

 extern unsigned char PowerShellRunnerDll[PSHRUNNER_DLL_LEN];

 #endif

